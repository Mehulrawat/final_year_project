from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *
import random as rnd
from. forms import *

POPULATION_SIZE = 9
NUMB_OF_ELITE_SCHEDULES = 1
TOURNAMENT_SELECTION_SIZE = 3
MUTATION_RATE = 0.05


class Data:
    def __init__(self):
        #self._rooms = Room.objects.all()
        self._meetingTimes = MeetingTime.objects.all()
    #     self._instructors = Instructor.objects.all()
    #     self._computercourses = ComputerCourse.objects.all()
    #     self._computersem = ComputerSemester.objects.all()

    # #def get_rooms(self): return self._rooms

    # def get_instructors(self): return self._instructors

    # def get_computercourses(self): return self._computercourses

    # def get_computersem(self): return self._computersem

    def get_meetingTimes(self): return self._meetingTimes


class Schedule:
    def __init__(self):
        self._data = data
        self._classes = []
        self._numberOfConflicts = 0
        self._fitness = -1
        self._classNumb = 0
        self._isFitnessChanged = True

    def get_classes(self):
        self._isFitnessChanged = True
        return self._classes

    def get_numbOfConflicts(self): return self._numberOfConflicts

    def get_fitness(self):
        if self._isFitnessChanged:
            self._fitness = self.calculate_fitness()
            self._isFitnessChanged = False
        return self._fitness

    def initialize(self):

         
        fixed_classes1 = FixedClassComputer.objects.all() 
        for fixed_class in fixed_classes1:
            semester = fixed_class.semester
            dept_code=ComputerSemester.dept_code
            course=fixed_class.course
            newClass = Class(self._classNumb,dept_code,semester,course)
            self._classNumb += 1
            newClass.set_meetingTime(fixed_class.meeting_time)
           
            newClass.set_instructor(fixed_class.instructor)
            self._classes.append(newClass)

        fixed_classes2 = FixedClassElectronics.objects.all() 
        for fixed_class in fixed_classes2:
            semester = fixed_class.semester
            dept_code=ElectronicsSemester.dept_code
            course=fixed_class.course
            newClass = Class(self._classNumb,dept_code,semester,course)
            self._classNumb += 1
            newClass.set_meetingTime(fixed_class.meeting_time)
           
            newClass.set_instructor(fixed_class.instructor)
            self._classes.append(newClass)
        
      
        selectsemesters = Selectsemester.objects.all() 
        for selectsemester in selectsemesters:
             
                semester = selectsemester.electronicssemester
                if semester is not None:
                    select_semester_id = semester
                    dept_code=ElectronicsSemester.dept_code
                    courses = semester.courses.all() 
                    for course in courses:
                        # Count the number of fixed classes for this course
                        fixed_class_count = sum(1 for fixed_class in fixed_classes2 if fixed_class.course == course)

                        # Generate the remaining classes needed to match the credit hours
                        remaining_classes_to_generate = course.credit_hours - fixed_class_count

                        for i in range(remaining_classes_to_generate):
                            crs_inst = course.instructors.all()
                            newClass = Class(self._classNumb,dept_code,  select_semester_id, course)
                            self._classNumb += 1
                            newClass.set_meetingTime(data.get_meetingTimes()[rnd.randrange(0, len(MeetingTime.objects.all()))])
                            newClass.set_instructor(crs_inst[rnd.randrange(0, len(crs_inst))])
                            self._classes.append(newClass)
                        
                    
                semester = selectsemester.computersemester
                if semester is not None:
                    dept_code=ComputerSemester.dept_code
                    select_semester_id = semester
                    courses = semester.courses.all() 
                    for course in courses:
                        # Count the number of fixed classes for this course
                        fixed_class_count = sum(1 for fixed_class in fixed_classes1 if fixed_class.course == course)

                        # Generate the remaining classes needed to match the credit hours
                        remaining_classes_to_generate = course.credit_hours - fixed_class_count

                        for i in range(remaining_classes_to_generate):
                            crs_inst = course.instructors.all()
                            newClass = Class(self._classNumb,dept_code,select_semester_id, course)
                            self._classNumb += 1
                            newClass.set_meetingTime(data.get_meetingTimes()[rnd.randrange(0, len(MeetingTime.objects.all()))])
                            newClass.set_instructor(crs_inst[rnd.randrange(0, len(crs_inst))])
                            self._classes.append(newClass)

        return self

    def calculate_fitness(self):
        
        self._numberOfConflicts = 0
        
        classes = self.get_classes()
        for i in range(len(classes)):
            #if classes[i].seating_capacity < int(classes[i].course.max_numb_students): 
            if classes[i].seating_capacity < 48:         
                self._numberOfConflicts += 1
          
            for j in range(len(classes)):
                if j >= i:
                   
                    
                    if (classes[i].meeting_time == classes[j].meeting_time) and \
                            (classes[i].class_id != classes[j].class_id) and \
                           (classes[i].select_semester_id == classes[j].select_semester_id):
                           
                             self._numberOfConflicts += 1
                             


                    if(classes[i].select_semester_id != classes[j].select_semester_id and \
                       classes[i].meeting_time == classes[j].meeting_time and \
                       classes[i].class_id != classes[j].class_id):
                            
                        if (classes[i].instructor==classes[j].instructor):
                            self._numberOfConflicts += 1
                            
                    if (classes[i].select_semester_id == classes[j].select_semester_id) and \
                        (classes[i].meeting_time.day == classes[j].meeting_time.day) and \
                        (classes[i].meeting_time.time != classes[j].meeting_time.time) and \
                        (classes[i].instructor==classes[j].instructor):
                        
                         self._numberOfConflicts += 1
                             
        return 1 / (1.0 * self._numberOfConflicts + 1)


class Population:
    def __init__(self, size):
        self._size = size
        self._data = data
        self._schedules = [Schedule().initialize() for i in range(size)]

    def get_schedules(self):
        return self._schedules


class GeneticAlgorithm:
    def evolve(self, population):
        return self._mutate_population(self._crossover_population(population))

    def _crossover_population(self, pop):
        crossover_pop = Population(0)
        for i in range(NUMB_OF_ELITE_SCHEDULES):
            crossover_pop.get_schedules().append(pop.get_schedules()[i])
        i = NUMB_OF_ELITE_SCHEDULES
        while i < POPULATION_SIZE:
            schedule1 = self._select_tournament_population(pop).get_schedules()[0]
            schedule2 = self._select_tournament_population(pop).get_schedules()[0]
            crossover_pop.get_schedules().append(self._crossover_schedule(schedule1, schedule2))
            i += 1
        return crossover_pop

    def _mutate_population(self, population):
        for i in range(NUMB_OF_ELITE_SCHEDULES, POPULATION_SIZE):
            self._mutate_schedule(population.get_schedules()[i])
        return population

    def _crossover_schedule(self, schedule1, schedule2):
        crossoverSchedule = Schedule().initialize()
        for i in range(0, len(crossoverSchedule.get_classes())):
            if rnd.random() > 0.5:
                crossoverSchedule.get_classes()[i] = schedule1.get_classes()[i]
            else:
                crossoverSchedule.get_classes()[i] = schedule2.get_classes()[i]
        return crossoverSchedule

    def _mutate_schedule(self, mutateSchedule):
        schedule = Schedule().initialize()
        for i in range(len(mutateSchedule.get_classes())):
            if MUTATION_RATE > rnd.random():
                mutateSchedule.get_classes()[i] = schedule.get_classes()[i]
        return mutateSchedule

    def _select_tournament_population(self, pop):
        tournament_pop = Population(0)
        i = 0
        while i < TOURNAMENT_SELECTION_SIZE:
            tournament_pop.get_schedules().append(pop.get_schedules()[rnd.randrange(0, POPULATION_SIZE)])
            i += 1
        tournament_pop.get_schedules().sort(key=lambda x: x.get_fitness(), reverse=True)
        return tournament_pop


class Class:
    def __init__(self, id, dept_code, select_semester_id, course):
        self.class_id = id
        # self.semester = sem
        self.department_code=dept_code
        self.course = course
        self.instructor = None
        self.meeting_time = None
        #self.room = None
        self.select_semester_id=select_semester_id
        self.seating_capacity=48

    def get_id(self): return self.class_id

    def get_dept_code(self): return self.department_code

    def get_course(self): return self.course

    def get_instructor(self): return self.instructor

    def get_meetingTime(self): return self.meeting_time

    #def get_room(self): return self.room

    def set_instructor(self, instructor): self.instructor = instructor

    def set_meetingTime(self, meetingTime): self.meeting_time = meetingTime

    #def set_room(self, room): self.room = room
    


data = Data()


def context_manager(schedule):
    classes = schedule.get_classes()
    context = []
    cls = {}
    for i in range(len(classes)):
        cls["selectsemester"] = classes[i].select_semester_id
        cls['sem'] = classes[i].semester.semester
        cls['course'] = f'{classes[i].course.course_name} ({classes[i].course.course_number}, ' \
                        f'{classes[i].course.max_numb_students}'
       
        cls['instructor'] = f'{classes[i].instructor.name} ({classes[i].instructor.uid})'
        cls['meeting_time'] = [classes[i].meeting_time.pid, classes[i].meeting_time.day, classes[i].meeting_time.time]
        context.append(cls)
    return context


     #login form
def home(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('base')  
            else:
                form.add_error(None, "Invalid username or password")
    else:
        form = LoginForm()
    return render(request, 'index.html', {'form': form})
    #login form

def base(request):
    if request.user.is_authenticated:
        return render(request, 'base.html')
    else:
        return redirect('home')

def in_comp(request):
    return render(request, 'in_comp.html')
#def home(request):
    #return render(request, 'index.html', {})


def in_elex(request):
    return render(request, 'in_elex.html')

def logout(request):
     form = LoginForm()
     return render(request, 'index.html',{'form': form})



def timetable(request):
    schedule = []
    population = Population(POPULATION_SIZE)
    generation_num = 0
    population.get_schedules().sort(key=lambda x: x.get_fitness(), reverse=True)
    geneticAlgorithm = GeneticAlgorithm()
    # print("pop",population.get_schedules()[0].get_fitness())
    while population.get_schedules()[0].get_fitness() != 1.0:
        generation_num += 1
        print('\n> Generation #' + str(generation_num))
        population = geneticAlgorithm.evolve(population)
        # print("after while")
        population.get_schedules().sort(key=lambda x: x.get_fitness(), reverse=True)
        schedule = population.get_schedules()[0].get_classes()

    context = {
        'schedule': schedule,
        'selectsemesters': Selectsemester.objects.all(),
        'times': MeetingTime.objects.all(),
        'time_slots': time_slots,  
        'days_of_week': DAYS_OF_WEEK, 
    }

    return render(request, 'timetable.html', context)



def add_instructor(request):
    form = InstructorForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addinstructor')
    context = {
        'form': form
    }
    return render(request, 'adins.html', context)


def inst_list_view(request):
    context = {
        'instructors': Instructor.objects.all()
    }
    return render(request, 'instlist.html', context)


def delete_instructor(request, pk):
    inst = Instructor.objects.filter(pk=pk)
    if request.method == 'POST':
        inst.delete()
        return redirect('editinstructor')


# def add_room(request):
#     form = RoomForm(request.POST or None)
#     if request.method == 'POST':
#         if form.is_valid():
#             form.save()
#             return redirect('addroom')
#     context = {
#         'form': form
#     }
#     return render(request, 'addrm.html', context)


# def room_list(request):
#     context = {
#         'rooms': Room.objects.all()
#     }
#     return render(request, 'rmlist.html', context)


# def delete_room(request, pk):
#     rm = Room.objects.filter(pk=pk)
#     if request.method == 'POST':
#         rm.delete()
#         return redirect('editrooms')


def meeting_list_view(request):
    context = {
        'meeting_times': MeetingTime.objects.all()
    }
    return render(request, 'mtlist.html', context)


def add_meeting_time(request):
    form = MeetingTimeForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addmeetingtime')
        else:
            print('Invalid')
    context = {
        'form': form
    }
    return render(request, 'addmt.html', context)


def delete_meeting_time(request, pk):
    mt = MeetingTime.objects.filter(pk=pk)
    if request.method == 'POST':
        mt.delete()
        return redirect('editmeetingtime')


def course_list_view_computer(request):
    context = {
        'courses': ComputerCourse.objects.all()
    }
    return render(request, 'course_list_computer.html', context)


def add_course_computer(request):
    form = ComputerCourseForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addcoursecomputer')
        else:
            print('Invalid')
    context = {
        'form': form
    }
    return render(request, 'add_course_computer.html', context)


def delete_course_computer(request, pk):
    crs = ComputerCourse.objects.filter(pk=pk)
    if request.method == 'POST':
        crs.delete()
        return redirect('editcoursecomputer')


def add_semester_computer(request):
    form = ComputerSemesterForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addsemestercomputer')
    context = {
        'form': form
    }
    return render(request, 'add_semester_computer.html', context)


def semester_list_computer(request):
    context = {
        'semesters': ComputerSemester.objects.all()
    }
    return render(request, 'semester_list_computer.html', context)


def delete_semester_computer(request, pk):
    dept = ComputerSemester.objects.filter(pk=pk)
    if request.method == 'POST':
        dept.delete()
        return redirect('editsemestercomputer')

def delete_semester_computer(request, pk):
    dept = ComputerSemester.objects.filter(pk=pk)
    if request.method == 'POST':
        dept.delete()
        return redirect('editsemestercomputer') 

#for electronics

def course_list_view_electronics(request):
    context = {
        'courses': ElectronicsCourse.objects.all()
    }
    return render(request, 'course_list_electronics.html', context)


def add_course_electronics(request):
    form = ElectronicsCourseForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addcourseelectronics')
        else:
            print('Invalid')
    context = {
        'form': form
    }
    return render(request, 'add_course_electronics.html', context)


def delete_course_electronics(request, pk):
    crs = ElectronicsCourse.objects.filter(pk=pk)
    if request.method == 'POST':
        crs.delete()
        return redirect('editcourseelectronics')


def add_semester_electronics(request):
    form = ElectronicsSemesterForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addsemesterelectronics')
    context = {
        'form': form
    }
    return render(request, 'add_semester_electronics.html', context)


def semester_list_electronics(request):
    context = {
        'semesters': ElectronicsSemester.objects.all()
    }
    return render(request, 'semester_list_electronics.html', context)

def delete_semester_electronics(request, pk):
    dept = ElectronicsSemester.objects.filter(pk=pk)
    if request.method == 'POST':
        dept.delete()
        return redirect('editsemesterelectronics') 

#select semester

   
def add_select_semester(request):
    form = SelectsemesterForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addselectsemester')
    context = {
        'form': form
    }
    return render(request, 'add_select_semester.html', context)


def select_semester_list(request):
    context = {
        'selectsemesters': Selectsemester.objects.all()
    }
    return render(request, 'select_semester_list.html', context)

def delete_select_semester(request, pk):
    sec = Selectsemester.objects.filter(pk=pk)
    if request.method == 'POST':
        sec.delete()
        return redirect('editselectsemester')


def add_fixed_class_computer(request):
    form = FixedClassComputerForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addfixedclasscomputer')
    context = {
        'form': form
    }
    return render(request, 'add_fixedclass_computer.html', context)

def delete_fixed_class_computer(request, pk):
    fixclass = FixedClassComputer.objects.filter(pk=pk)
    if request.method == 'POST':
        fixclass.delete()
        return redirect('editfixedclasscomputer')

def fixed_class_list_computer(request):
    context = {
        'fixedclasses': FixedClassComputer.objects.all()
    }
    return render(request, 'fixed_class_list_computer.html', context)


#for fixed class electronics
def add_fixed_class_electronics(request):
    form = FixedClassElectronicsForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect('addfixedclasselectronics')
    context = {
        'form': form
    }
    return render(request, 'add_fixedclass_electronics.html', context)

def delete_fixed_class_electronics(request, pk):
    fixclass = FixedClassElectronics.objects.filter(pk=pk)
    if request.method == 'POST':
        fixclass.delete()
        return redirect('editfixedclasselectronics')

def fixed_class_list_electronics(request):
    context = {
        'fixedclasses': FixedClassElectronics.objects.all()
    }
    return render(request, 'fixed_class_list_electronics.html', context)


