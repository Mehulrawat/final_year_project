from django.contrib import admin
from django.urls import path, include
from. import views

urlpatterns = [
    path('base', views.base,name='base'),
    path('', views.home, name='home'),
    path('timetable_generation/', views.timetable, name='timetable'),
    path('in_comp/', views.in_comp, name='in_comp'),
    path('in_elex/', views.in_elex, name='in_elex'),
    path('logout/', views.logout, name='logout'),
    #path('add_room/', views.add_room, name='addroom'),
    path('add_instructor/', views.add_instructor, name='addinstructor'),
    path('instructor_list/', views.inst_list_view, name='editinstructor'),
    path('add_meetingtime/', views.add_meeting_time, name='addmeetingtime'),
    path('meetingtime_list/', views.meeting_list_view, name='editmeetingtime'),
    #computer
    path('add_course_computer/', views.add_course_computer, name='addcoursecomputer'),
    path('course_list_computer/', views.course_list_view_computer, name='editcoursecomputer'),
    path('delete_course_computer/<str:pk>/', views.delete_course_computer, name='deletecoursecomputer'),
    #electronics
    path('add_course_electronics/', views.add_course_electronics, name='addcourseelectronics'),
    path('course_list_electronics/', views.course_list_view_electronics, name='editcourseelectronics'),
    path('delete_course_electronics/<str:pk>/', views.delete_course_electronics, name='deletecourseelectronics'),
    
    path('delete_meetingtime/<str:pk>/', views.delete_meeting_time, name='deletemeetingtime'),
    path('delete_instructor/<int:pk>/', views.delete_instructor, name='deleteinstructor'),
    
    path('add_fixed_class_computer/', views.add_fixed_class_computer, name='addfixedclasscomputer'),
    path('delete_fixed_class_computer/<int:pk>/', views.delete_fixed_class_computer, name='deletefixedclasscomputer'),
    path('fixed_class_list_computer/', views.fixed_class_list_computer, name='editfixedclasscomputer'),

     path('add_fixed_class_electronics/', views.add_fixed_class_electronics, name='addfixedclasselectronics'),
    path('delete_fixed_class_electronics/<int:pk>/', views.delete_fixed_class_electronics, name='deletefixedclasselectronics'),
    path('fixed_class_list_electronics/', views.fixed_class_list_electronics, name='editfixedclasselectronics'),
    #computer
    path('add_semester_computer/', views.add_semester_computer, name='addsemestercomputer'),
    path('semester_list_computer/', views.semester_list_computer, name='editsemestercomputer'),
    path('delete_semester_computer/<int:pk>/', views.delete_semester_computer, name='deletesemestercomputer'),
    
    #electronics
    
    path('add_semester_electronics/', views.add_semester_electronics, name='addsemesterelectronics'),
    path('semester_list_electronics/', views.semester_list_electronics, name='editsemesterelectronics'),
    path('delete_semester_electronics/<int:pk>/', views.delete_semester_electronics, name='deletesemesterelectronics'),
    
    path('add_select_semester/', views.add_select_semester, name='addselectsemester'),
    path('select_semester_list/', views.select_semester_list, name='editselectsemester'),
    path('delete_select_semester/<str:pk>/', views.delete_select_semester, name='deleteselectsemester'),

]
